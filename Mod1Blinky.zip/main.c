#include <stdio.h>

int main(int argc, char *argv[])
{
    printf("connected\n");

    return 0;
}
